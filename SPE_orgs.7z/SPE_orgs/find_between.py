# coding=utf8
# name = input('Введите год.')
from collections import Counter

import re
start_year = 1990
end_year = 2019
name = start_year
count = 0
year_num = 0
total_org = []
# file_out=open('coauthors_data.txt', 'w')
industry_list = []
industry_dict = {}
comp_list = ['Schlumberger', 'WesternGeco', 'CGG', 'BGP CNPC', 'BP', 'ExxonMobil Upstream Research Company', 'CGGVeritas','Saudi Aramco','PGS','TGS','BGP','Kuwait Oil Company','ConocoPhillips','Western Geophysical','Statoil','Total','Petrobras','Hess Corporation','Halliburton']
org_count_total = 0
aver_coauth_numb_SPE = []
n_of_authors_all=[]
n_of_papers_all =[]
while name < end_year+1:
# Counter of organization
    org_count = 0
    
    n_of_authors_annual = []
    n_of_papers_annual = 0
    file=open(str(name) + '_temp.txt', encoding="utf8")
    data = file.read()
    block_of_lines = []
    # print(data)
    # quit()
    # block_of_lines = re.findall(r'SPE\n[\w+[,.?!:\;, -?...()\[\]\*]*]*\n(.*?)'+str(name)+'-',data , re.DOTALL)
    block_of_lines = re.findall(r'SPE\n[\w+[,.?!:\;, -?...()\[\]\*]*]*\n(.*?)SPE',data , re.DOTALL)
    name += 1
#    print(len(block_of_lines))
    n_of_papers_annual = len(block_of_lines)
    for element in block_of_lines:
        my_list =  element.split("\n")
#        Кол-во авторов на статью
        
        n_of_authors_annual.append(len(my_list)-1)
        
    n_of_authors_all.append(sum(n_of_authors_annual))
    n_of_papers_all.append(n_of_papers_annual)

for ii in range(0, len(n_of_authors_all)-1):
    if n_of_papers_all[ii] > 0:
        aver_coauth_numb_SPE.append(n_of_authors_all[ii]/n_of_papers_all[ii])
    else:
        aver_coauth_numb_SPE.append(0)

print(n_of_papers_all)
print(n_of_authors_all)
print(aver_coauth_numb_SPE)
    
    

       
#    quit()
#    file_out = open(str(name) + 'org_out_new.txt', 'w')
#
#    for item in block_of_lines:
#        print(item)
#        print(item, file = file_out, end = '')
#
#    file_out.close()
#
#    file_out = open(str(name) + 'org_out.txt','r')
#    temp_line = []
#    temp_str = ''
#    all_org = []
#    for line in file_out:
#         temp_line = line.split(',')
#         temp_str = ''.join(temp_line[2:])
#         # print(temp_str, end='')
#         all_org.append(temp_str)
#         total_org.append(temp_str[1:])
#    file.close()
#    file_out.close()
#
#    file_out = open(str(name) + 'org_out.txt', 'w')
#
#    for item in all_org:
#        print(item[1:], file = file_out, end = '')
#
#        if comp_list[0] in item:
#            org_count = org_count + 1

        # for comp_name in comp_list:
        #     if comp_name in item:
        #         print(item)
        #
        #         # if industry_dict == {}:
        #             # industry_list.append(item)
        #         # else:
        #             # if item in industry_list:
        #                 # continue
        #             # else:
        #                 # industry_list.append(item)
        #     else:
        #         continue
#    print(name, org_count)
#    org_count_total = org_count_total + org_count
#    file_out.close()
#    name = name + 1
#
# print("Schlumberger total:", org_count_total)
# for item in industry_list:
#     item = item.replace('\n','')

# print(industry_list)
# print('University of Houston', len(industry_list))
#print(len(total_org))
#myset = set(total_org)
#total_org = [w.replace('\n', '') for w in total_org]
#file_out_all_nn = open('all_for_years_nonum.txt', 'w')
#file_out_all = open('all_for_years.txt', 'w')
#list_org = Counter(total_org)
#sum = 0
#for key, value in list_org.most_common():
#    print(key, value, file = file_out_all)
#    print(key, file = file_out_all_nn)
#    sum = sum + value
#
#print(sum)
# print(Counter)



# print(total_org, file = file_out_all)

# for item in total_org:
#     print(item,  file = file_out_all)
# result = []
# for entry in set(total_org):
#     result.append((entry, total_org.count(entry)))
# result.sort(key = lambda x: -x[1])

# for item in result:
# #     mystring = ' '.join(map(str, item))
# #      # mystring.replace('\n\r', '')
#      print(item, file = file_out_all)
# new_dict = dict(result)


# for key, value in new_dict.items():
#     print(key, value)

# print(new_dict)

#industry_dict = {}
## print(industry_list)
#
#
#file_out_all.close()

# with open('1982organizations.txt', encoding="utf8") as input_data:
#     # Skips text before the beginning of the interesting block:
#     for line in input_data:
#         if line.strip() == 'SEG':  # Or whatever test is needed
#             input_data.readlines(1)
#             break
#     # Reads text until the end of the block:
#     for line in input_data:  # This keeps reading the file
#         if '- 1982\n' in line:
#             break
#         block_of_lines.append(line)  # Line is extracted (or block_of_lines.append(line), etc.)

# print(block_of_lines)

# count = 0
# count2 = 0
# for line in file:
#     if line == 'SEG\n':
#         print(next())
#         count = count +1
#          # '- 1982\n' not in line:
#          #    print(line)
#
#     #     count = count + 1
#     #
#     # if '- 1982\n' in line:
#     #     count2 = count2 + 1
#
# print(count)
# print(count2)

#
# def find_between(s, first, last):
#     try:
#         start = s.index( first) + len( first )
#         end = s.index( last, start )
#         return s[start:end]
#     except ValueError:
#         return ""
#
# def find_between_r(s, first, last ):
#     try:
#         start = s.rindex( first ) + len( first )
#         end = s.rindex( last, start )
#         return s[start:end]
#     except ValueError:
#         return ""

#
# print(find_between(s, "123", "abc" ))
# print(find_between_r(s, "123", "abc" ))
