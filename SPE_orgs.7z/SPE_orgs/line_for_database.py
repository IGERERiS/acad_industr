# -*- coding: utf-8 -*-
"""
Created on Sun Mar 29 10:57:42 2020

@author: eltsovt
"""
import pyperclip

while True:
    inp = input('Введите строку\n')
    inp = eval(inp)
    total_string = ''
    
    for counter in range(0, len(inp)):
        if counter == 0:
            total_string = total_string + '\"'+inp[0]+'\"'+' : '+ '(\''+inp[0]+'\', '
            print('\"',inp[0],'\"', ' : ', '(\'',inp[0],'\', ', sep = '', end = '')
        elif counter == len(inp)-1:
            total_string = total_string + '\''+inp[counter]+'\''+'), '
            print('\'',inp[counter],'\'', sep = '', end = '), ' )        
        else:
            total_string = total_string + '\''+inp[counter]+'\''+', '
            print('\'',inp[counter],'\'',', ', sep = '', end = '' )
    
    pyperclip.copy(total_string)    
